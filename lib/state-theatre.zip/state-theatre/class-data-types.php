<?php
/**
 * Custom site functionality.
 *
 * @package RHD
 */

/**
 * Registers post types and taxonomies
 */
class Data_Types extends RHD_Base {
	const CPT_SUPPORTS = array( 'title', 'thumbnail' );

	/**
	 * Constructor.
	 */
	public function __construct() {
		// `film` post type
		add_action( 'init', array( $this, 'film_init' ), 10 );
		add_filter( 'post_updated_messages', array( $this, 'film_updated_messages' ) );
		add_filter( 'bulk_post_updated_messages', array( $this, 'film_bulk_updated_messages' ), 10, 2 );

		// `live_event` post type
		add_action( 'init', array( $this, 'event_init' ), 10 );
		add_filter( 'post_updated_messages', array( $this, 'event_updated_messages' ) );
		add_filter( 'bulk_post_updated_messages', array( $this, 'event_bulk_updated_messages' ), 10, 2 );

		// `featured_slide` post type
		add_action( 'init', array( $this, 'featured_slide_init' ), 10 );
		add_filter( 'post_updated_messages', array( $this, 'featured_slide_updated_messages' ) );
		add_filter( 'bulk_post_updated_messages', array( $this, 'featured_slide_bulk_updated_messages' ), 10, 2 );

		// `film_event_category` taxonomy
		add_action( 'init', array( $this, 'film_event_category_init' ), 10 );
		add_filter( 'term_updated_messages', array( $this, 'film_event_category_updated_messages' ) );

		// `genre` taxonomy
		add_action( 'init', array( $this, 'genre_init' ), 10 );
		add_filter( 'term_updated_messages', array( $this, 'film_genre_updated_messages' ) );

		// `venue` taxonomy
		add_action( 'init', array( $this, 'venue_init' ), 10 );
		add_filter( 'term_updated_messages', array( $this, 'venue_updated_messages' ) );

		// Check the rewrite flag!
		add_action( 'init', array( $this, 'check_rewrite_flag' ), 20 );
	}

	/**
	 * Checks for the presense of the rewrite flag added on plugin activation, and flushes permalinks if needed.
	 *
	 * @return void
	 */
	public function check_rewrite_flag() {
		if ( get_option( 'rhd_state_theatre_rewrite_rules_flag' ) ) {
			flush_rewrite_rules();
			delete_option( 'rhd_state_theatre_rewrite_rules_flag' );
		}
	}

	/**
	 * Registers the `film` post type.
	 */
	public function film_init() {
		register_post_type(
			'film',
			array(
				'labels'                => array(
					'name'                  => __( 'Films', 'rhd' ),
					'singular_name'         => __( 'Film', 'rhd' ),
					'all_items'             => __( 'All Films', 'rhd' ),
					'archives'              => __( 'Film Archives', 'rhd' ),
					'attributes'            => __( 'Film Attributes', 'rhd' ),
					'insert_into_item'      => __( 'Insert into Film', 'rhd' ),
					'uploaded_to_this_item' => __( 'Uploaded to this Film', 'rhd' ),
					'featured_image'        => _x( 'Featured Image', 'film', 'rhd' ),
					'set_featured_image'    => _x( 'Set featured image', 'film', 'rhd' ),
					'remove_featured_image' => _x( 'Remove featured image', 'film', 'rhd' ),
					'use_featured_image'    => _x( 'Use as featured image', 'film', 'rhd' ),
					'filter_items_list'     => __( 'Filter Films list', 'rhd' ),
					'items_list_navigation' => __( 'Films list navigation', 'rhd' ),
					'items_list'            => __( 'Films list', 'rhd' ),
					'new_item'              => __( 'New Film', 'rhd' ),
					'add_new'               => __( 'Add New', 'rhd' ),
					'add_new_item'          => __( 'Add New Film', 'rhd' ),
					'edit_item'             => __( 'Edit Film', 'rhd' ),
					'view_item'             => __( 'View Film', 'rhd' ),
					'view_items'            => __( 'View Films', 'rhd' ),
					'search_items'          => __( 'Search Films', 'rhd' ),
					'not_found'             => __( 'No Films found', 'rhd' ),
					'not_found_in_trash'    => __( 'No Films found in trash', 'rhd' ),
					'parent_item_colon'     => __( 'Parent Film:', 'rhd' ),
					'menu_name'             => __( 'Films', 'rhd' ),
				),
				'public'                => true,
				'hierarchical'          => false,
				'show_ui'               => true,
				'show_in_nav_menus'     => true,
				'supports'              => self::CPT_SUPPORTS,
				'has_archive'           => true,
				'rewrite'               => array( 'slug' => 'films', 'with_front' => false ), // phpcs:ignore WordPress.Arrays.ArrayDeclarationSpacing.AssociativeArrayFound
				'query_var'             => true,
				'menu_position'         => null,
				'menu_icon'             => 'dashicons-editor-video',
				'show_in_rest'          => true,
				'rest_base'             => 'films',
				'rest_controller_class' => 'WP_REST_Posts_Controller',
				'taxonomies'            => array( 'film_event_category' ),
			)
		);
	}

	/**
	 * Sets the post updated messages for the `film` post type.
	 *
	 * @param  array $messages Post updated messages.
	 * @return array Messages for the `film` post type.
	 */
	public function film_updated_messages( $messages ) {
		global $post;

		$permalink = get_permalink( $post );

		$messages['film'] = array(
			0  => '', // Unused. Messages start at index 1.
			/* translators: %s: post permalink */
			1  => sprintf( __( 'Film updated. <a target="_blank" href="%s">View Film</a>', 'rhd' ), esc_url( $permalink ) ),
			2  => __( 'Custom field updated.', 'rhd' ),
			3  => __( 'Custom field deleted.', 'rhd' ),
			4  => __( 'Film updated.', 'rhd' ),
			/* translators: %s: date and time of the revision */
			5  => isset( $_GET['revision'] ) ? sprintf( __( 'Film restored to revision from %s', 'rhd' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false, // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			/* translators: %s: post permalink */
			6  => sprintf( __( 'Film published. <a href="%s">View Film</a>', 'rhd' ), esc_url( $permalink ) ),
			7  => __( 'Film saved.', 'rhd' ),
			/* translators: %s: post permalink */
			8  => sprintf( __( 'Film submitted. <a target="_blank" href="%s">Preview Film</a>', 'rhd' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
			/* translators: 1: Publish box date format, see https://secure.php.net/date 2: Post permalink */
			9  => sprintf( __( 'Film scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Film</a>', 'rhd' ), date_i18n( __( 'M j, Y @ G:i', 'rhd' ), strtotime( $post->post_date ) ), esc_url( $permalink ) ),
			/* translators: %s: post permalink */
			10 => sprintf( __( 'Film draft updated. <a target="_blank" href="%s">Preview Film</a>', 'rhd' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
		);

		return $messages;
	}

	/**
	 * Sets the bulk post updated messages for the `film` post type.
	 *
	 * @param  array $bulk_messages Arrays of messages, each keyed by the corresponding post type. Messages are
	 *                              keyed with 'updated', 'locked', 'deleted', 'trashed', and 'untrashed'.
	 * @param  int[] $bulk_counts   Array of item counts for each message, used to build internationalized strings.
	 * @return array Bulk messages for the `film` post type.
	 */
	public function film_bulk_updated_messages(
		$bulk_messages,
		$bulk_counts
	) {
		global $post;

		$bulk_messages['film'] = array(
			/* translators: %s: Number of Films. */
			'updated'   => _n( '%s Film updated.', '%s Films updated.', $bulk_counts['updated'], 'rhd' ),
			'locked'    => ( 1 === $bulk_counts['locked'] ) ? __( '1 Film not updated, somebody is editing it.', 'rhd' ) :
			/* translators: %s: Number of Films. */
			_n( '%s Film not updated, somebody is editing it.', '%s Films not updated, somebody is editing them.', $bulk_counts['locked'], 'rhd' ),
			/* translators: %s: Number of Films. */
			'deleted'   => _n( '%s Film permanently deleted.', '%s Films permanently deleted.', $bulk_counts['deleted'], 'rhd' ),
			/* translators: %s: Number of Films. */
			'trashed'   => _n( '%s Film moved to the Trash.', '%s Films moved to the Trash.', $bulk_counts['trashed'], 'rhd' ),
			/* translators: %s: Number of Films. */
			'untrashed' => _n( '%s Film restored from the Trash.', '%s Films restored from the Trash.', $bulk_counts['untrashed'], 'rhd' ),
		);

		return $bulk_messages;
	}

	/**
	 * Registers the `live_event` post type.
	 */
	public function event_init() {
		register_post_type(
			'live_event',
			array(
				'labels'                => array(
					'name'                  => __( 'Events', 'rhd' ),
					'singular_name'         => __( 'Event', 'rhd' ),
					'all_items'             => __( 'All Events', 'rhd' ),
					'archives'              => __( 'Event Archives', 'rhd' ),
					'attributes'            => __( 'Event Attributes', 'rhd' ),
					'insert_into_item'      => __( 'Insert into Event', 'rhd' ),
					'uploaded_to_this_item' => __( 'Uploaded to this Event', 'rhd' ),
					'featured_image'        => _x( 'Featured Image', 'live_event', 'rhd' ),
					'set_featured_image'    => _x( 'Set featured image', 'live_event', 'rhd' ),
					'remove_featured_image' => _x( 'Remove featured image', 'live_event', 'rhd' ),
					'use_featured_image'    => _x( 'Use as featured image', 'live_event', 'rhd' ),
					'filter_items_list'     => __( 'Filter Events list', 'rhd' ),
					'items_list_navigation' => __( 'Events list navigation', 'rhd' ),
					'items_list'            => __( 'Events list', 'rhd' ),
					'new_item'              => __( 'New Event', 'rhd' ),
					'add_new'               => __( 'Add New', 'rhd' ),
					'add_new_item'          => __( 'Add New Event', 'rhd' ),
					'edit_item'             => __( 'Edit Event', 'rhd' ),
					'view_item'             => __( 'View Event', 'rhd' ),
					'view_items'            => __( 'View Events', 'rhd' ),
					'search_items'          => __( 'Search Events', 'rhd' ),
					'not_found'             => __( 'No Events found', 'rhd' ),
					'not_found_in_trash'    => __( 'No Events found in trash', 'rhd' ),
					'parent_item_colon'     => __( 'Parent Event:', 'rhd' ),
					'menu_name'             => __( 'Events', 'rhd' ),
				),
				'public'                => true,
				'hierarchical'          => false,
				'show_ui'               => true,
				'show_in_nav_menus'     => true,
				'supports'              => self::CPT_SUPPORTS,
				'has_archive'           => true,
				'rewrite'               => array( 'slug' => 'events', 'with_front' => false ), // phpcs:ignore WordPress.Arrays.ArrayDeclarationSpacing.AssociativeArrayFound
				'query_var'             => true,
				'menu_position'         => null,
				'menu_icon'             => 'dashicons-star-filled',
				'show_in_rest'          => true,
				'rest_base'             => 'events',
				'rest_controller_class' => 'WP_REST_Posts_Controller',
				'taxonomies'            => array( 'film_event_category', 'film_genre' ),
			)
		);

	}

	/**
	 * Sets the post updated messages for the `live_event` post type.
	 *
	 * @param  array $messages Post updated messages.
	 * @return array Messages for the `live_event` post type.
	 */
	public function event_updated_messages( $messages ) {
		global $post;

		$permalink = get_permalink( $post );

		$messages['live_event'] = array(
			0  => '', // Unused. Messages start at index 1.
			/* translators: %s: post permalink */
			1  => sprintf( __( 'Event updated. <a target="_blank" href="%s">View Event</a>', 'rhd' ), esc_url( $permalink ) ),
			2  => __( 'Custom field updated.', 'rhd' ),
			3  => __( 'Custom field deleted.', 'rhd' ),
			4  => __( 'Event updated.', 'rhd' ),
			/* translators: %s: date and time of the revision */
			5  => isset( $_GET['revision'] ) ? sprintf( __( 'Event restored to revision from %s', 'rhd' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false, // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			/* translators: %s: post permalink */
			6  => sprintf( __( 'Event published. <a href="%s">View Event</a>', 'rhd' ), esc_url( $permalink ) ),
			7  => __( 'Event saved.', 'rhd' ),
			/* translators: %s: post permalink */
			8  => sprintf( __( 'Event submitted. <a target="_blank" href="%s">Preview Event</a>', 'rhd' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
			/* translators: 1: Publish box date format, see https://secure.php.net/date 2: Post permalink */
			9  => sprintf( __( 'Event scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Event</a>', 'rhd' ), date_i18n( __( 'M j, Y @ G:i', 'rhd' ), strtotime( $post->post_date ) ), esc_url( $permalink ) ),
			/* translators: %s: post permalink */
			10 => sprintf( __( 'Event draft updated. <a target="_blank" href="%s">Preview Event</a>', 'rhd' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
		);

		return $messages;
	}

	/**
	 * Registers the `featured_slide` post type.
	 */
	public function featured_slide_init() {
		register_post_type(
			'featured_slide',
			array(
				'labels'                => array(
					'name'                  => __( 'Featured Slides', 'rhd' ),
					'singular_name'         => __( 'Featured Slide', 'rhd' ),
					'all_items'             => __( 'All Featured Slides', 'rhd' ),
					'archives'              => __( 'Featured Slide Archives', 'rhd' ),
					'attributes'            => __( 'Featured Slide Attributes', 'rhd' ),
					'insert_into_item'      => __( 'Insert into featured slide', 'rhd' ),
					'uploaded_to_this_item' => __( 'Uploaded to this featured slide', 'rhd' ),
					'featured_image'        => _x( 'Featured Image', 'featured_slide', 'rhd' ),
					'set_featured_image'    => _x( 'Set featured image', 'featured_slide', 'rhd' ),
					'remove_featured_image' => _x( 'Remove featured image', 'featured_slide', 'rhd' ),
					'use_featured_image'    => _x( 'Use as featured image', 'featured_slide', 'rhd' ),
					'filter_items_list'     => __( 'Filter Featured Slides list', 'rhd' ),
					'items_list_navigation' => __( 'Featured Slides list navigation', 'rhd' ),
					'items_list'            => __( 'Featured Slides list', 'rhd' ),
					'new_item'              => __( 'New Featured Slide', 'rhd' ),
					'add_new'               => __( 'Add New Slide', 'rhd' ),
					'add_new_item'          => __( 'Add New Slide', 'rhd' ),
					'edit_item'             => __( 'Edit Featured Slide', 'rhd' ),
					'view_item'             => __( 'View Featured Slide', 'rhd' ),
					'view_items'            => __( 'View Featured Slides', 'rhd' ),
					'search_items'          => __( 'Search Featured Slides', 'rhd' ),
					'not_found'             => __( 'No Featured Slides found', 'rhd' ),
					'not_found_in_trash'    => __( 'No Featured Slides found in trash', 'rhd' ),
					'parent_item_colon'     => __( 'Parent Featured Slide:', 'rhd' ),
					'menu_name'             => __( 'Featured Slides', 'rhd' ),
				),
				'public'                => true,
				'hierarchical'          => false,
				'show_ui'               => true,
				'show_in_nav_menus'     => true,
				'supports'              => array( 'title', 'editor' ),
				'has_archive'           => true,
				'rewrite'               => true,
				'query_var'             => true,
				'menu_position'         => null,
				'menu_icon'             => 'dashicons-admin-post',
				'show_in_rest'          => true,
				'exclude_from_search'   => true,
				'rest_base'             => 'featured_slide',
				'rest_controller_class' => 'WP_REST_Posts_Controller',
				'template'              => array(
					array(
						'core/cover',
						array(
							'align' => 'full',
						),
						array(
							array(
								'core/heading',
								array(
									'level' => '3',
									'align' => 'left',
								),
							),
							array(
								'core/paragraph',
								array(
									'align'       => 'left',
									'description' => 'Add Description...',
								),
							),
							array(
								'core/buttons',
								array(
									'align' => 'left',
								),
							),
						),
					),
				),
			)
		);
	}

	/**
	 * Sets the post updated messages for the `featured_slide` post type.
	 *
	 * @param  array $messages Post updated messages.
	 * @return array Messages for the `featured_slide` post type.
	 */
	public function featured_slide_updated_messages( $messages ) {
		global $post;

		$permalink = get_permalink( $post );

		$messages['featured_slide'] = array(
			0  => '', // Unused. Messages start at index 1.
			/* translators: %s: post permalink */
			1  => sprintf( __( 'Featured Slide updated. <a target="_blank" href="%s">View featured slide</a>', 'rhd' ), esc_url( $permalink ) ),
			2  => __( 'Custom field updated.', 'rhd' ),
			3  => __( 'Custom field deleted.', 'rhd' ),
			4  => __( 'Featured Slide updated.', 'rhd' ),
			/* translators: %s: date and time of the revision */
			5  => isset( $_GET['revision'] ) ? sprintf( __( 'Featured Slide restored to revision from %s', 'rhd' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false, // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			/* translators: %s: post permalink */
			6  => sprintf( __( 'Featured Slide published. <a href="%s">View featured slide</a>', 'rhd' ), esc_url( $permalink ) ),
			7  => __( 'Featured Slide saved.', 'rhd' ),
			/* translators: %s: post permalink */
			8  => sprintf( __( 'Featured Slide submitted. <a target="_blank" href="%s">Preview featured slide</a>', 'rhd' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
			/* translators: 1: Publish box date format, see https://secure.php.net/date 2: Post permalink */
			9  => sprintf( __( 'Featured Slide scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview featured slide</a>', 'rhd' ), date_i18n( __( 'M j, Y @ G:i', 'rhd' ), strtotime( $post->post_date ) ), esc_url( $permalink ) ),
			/* translators: %s: post permalink */
			10 => sprintf( __( 'Featured Slide draft updated. <a target="_blank" href="%s">Preview featured slide</a>', 'rhd' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
		);

		return $messages;
	}

	/**
	 * Sets the bulk post updated messages for the `featured_slide` post type.
	 *
	 * @param  array $bulk_messages Arrays of messages, each keyed by the corresponding post type. Messages are
	 *                              keyed with 'updated', 'locked', 'deleted', 'trashed', and 'untrashed'.
	 * @param  int[] $bulk_counts   Array of item counts for each message, used to build internationalized strings.
	 * @return array Bulk messages for the `featured_slide` post type.
	 */
	public function featured_slide_bulk_updated_messages( $bulk_messages, $bulk_counts ) {
		global $post;

		$bulk_messages['featured_slide'] = array(
			/* translators: %s: Number of Featured Slides. */
			'updated'   => _n( '%s featured slide updated.', '%s Featured Slides updated.', $bulk_counts['updated'], 'rhd' ),
			'locked'    => ( 1 === $bulk_counts['locked'] ) ? __( '1 featured slide not updated, somebody is editing it.', 'rhd' ) :
			/* translators: %s: Number of Featured Slides. */
			_n( '%s featured slide not updated, somebody is editing it.', '%s Featured Slides not updated, somebody is editing them.', $bulk_counts['locked'], 'rhd' ),
			/* translators: %s: Number of Featured Slides. */
			'deleted'   => _n( '%s featured slide permanently deleted.', '%s Featured Slides permanently deleted.', $bulk_counts['deleted'], 'rhd' ),
			/* translators: %s: Number of Featured Slides. */
			'trashed'   => _n( '%s featured slide moved to the Trash.', '%s Featured Slides moved to the Trash.', $bulk_counts['trashed'], 'rhd' ),
			/* translators: %s: Number of Featured Slides. */
			'untrashed' => _n( '%s featured slide restored from the Trash.', '%s Featured Slides restored from the Trash.', $bulk_counts['untrashed'], 'rhd' ),
		);

		return $bulk_messages;
	}

	/**
	 * Sets the bulk post updated messages for the `live_event` post type.
	 *
	 * @param  array $bulk_messages Arrays of messages, each keyed by the corresponding post type. Messages are
	 *                              keyed with 'updated', 'locked', 'deleted', 'trashed', and 'untrashed'.
	 * @param  int[] $bulk_counts   Array of item counts for each message, used to build internationalized strings.
	 * @return array Bulk messages for the `live_event` post type.
	 */
	public function event_bulk_updated_messages( $bulk_messages, $bulk_counts ) {
		global $post;

		$bulk_messages['live_event'] = array(
			/* translators: %s: Number of Events. */
			'updated'   => _n( '%s Event updated.', '%s Events updated.', $bulk_counts['updated'], 'rhd' ),
			'locked'    => ( 1 === $bulk_counts['locked'] ) ? __( '1 Event not updated, somebody is editing it.', 'rhd' ) :
			/* translators: %s: Number of Events. */
			_n( '%s Event not updated, somebody is editing it.', '%s Events not updated, somebody is editing them.', $bulk_counts['locked'], 'rhd' ),
			/* translators: %s: Number of Events. */
			'deleted'   => _n( '%s Event permanently deleted.', '%s Events permanently deleted.', $bulk_counts['deleted'], 'rhd' ),
			/* translators: %s: Number of Events. */
			'trashed'   => _n( '%s Event moved to the Trash.', '%s Events moved to the Trash.', $bulk_counts['trashed'], 'rhd' ),
			/* translators: %s: Number of Events. */
			'untrashed' => _n( '%s Event restored from the Trash.', '%s Events restored from the Trash.', $bulk_counts['untrashed'], 'rhd' ),
		);

		return $bulk_messages;
	}

	/**
	 * Registers the `film_event_category` taxonomy,
	 * for use with 'film', 'live_event'.
	 */
	public function film_event_category_init() {
		register_taxonomy(
			'film_event_category',
			array( 'film', 'live_event' ),
			array(
				'hierarchical'          => true,
				'public'                => true,
				'show_in_nav_menus'     => true,
				'show_ui'               => true,
				'show_admin_column'     => true,
				'query_var'             => true,
				'rewrite'               => array(
					'slug'       => 'show-category',
					'with_front' => false,
				),
				'capabilities'          => array(
					'manage_terms' => 'edit_posts',
					'edit_terms'   => 'edit_posts',
					'delete_terms' => 'edit_posts',
					'assign_terms' => 'edit_posts',
				),
				'labels'                => array(
					'name'                       => __( 'Show Categories', 'rhd' ),
					'singular_name'              => _x( 'Show Category', 'taxonomy general name', 'rhd' ),
					'search_items'               => __( 'Search Show Categories', 'rhd' ),
					'popular_items'              => __( 'Popular Show Categories', 'rhd' ),
					'all_items'                  => __( 'All Show Categories', 'rhd' ),
					'parent_item'                => __( 'Parent Show Category', 'rhd' ),
					'parent_item_colon'          => __( 'Parent Show Category:', 'rhd' ),
					'edit_item'                  => __( 'Edit Show Category', 'rhd' ),
					'update_item'                => __( 'Update Show Category', 'rhd' ),
					'view_item'                  => __( 'View Show Category', 'rhd' ),
					'add_new_item'               => __( 'Add New Show Category', 'rhd' ),
					'new_item_name'              => __( 'New Show Category', 'rhd' ),
					'separate_items_with_commas' => __( 'Separate Show Categories with commas', 'rhd' ),
					'add_or_remove_items'        => __( 'Add or remove Show Categories', 'rhd' ),
					'choose_from_most_used'      => __( 'Choose from the most used Show Categories', 'rhd' ),
					'not_found'                  => __( 'No Show Categories found.', 'rhd' ),
					'no_terms'                   => __( 'No Show Categories', 'rhd' ),
					'menu_name'                  => __( 'Show Categories', 'rhd' ),
					'items_list_navigation'      => __( 'Show Categories list navigation', 'rhd' ),
					'items_list'                 => __( 'Show Categories list', 'rhd' ),
					'most_used'                  => _x( 'Most Used', 'film_event_category', 'rhd' ),
					'back_to_items'              => __( '&larr; Back to Show Categories', 'rhd' ),
				),
				'show_in_rest'          => true,
				'rest_base'             => 'show_category',
				'rest_controller_class' => 'WP_REST_Terms_Controller',
			)
		);
	}

	/**
	 * Sets the post updated messages for the `film_event_category` taxonomy.
	 *
	 * @param  array $messages Post updated messages.
	 * @return array Messages for the `film_event_category` taxonomy.
	 */
	public function film_event_category_updated_messages( $messages ) {
		$messages['film_event_category'] = array(
			0 => '', // Unused. Messages start at index 1.
			1 => __( 'Show Category added.', 'rhd' ),
			2 => __( 'Show Category deleted.', 'rhd' ),
			3 => __( 'Show Category updated.', 'rhd' ),
			4 => __( 'Show Category not added.', 'rhd' ),
			5 => __( 'Show Category not updated.', 'rhd' ),
			6 => __( 'Show Categories deleted.', 'rhd' ),
		);

		return $messages;
	}

	/**
	 * Registers the `film_genre` taxonomy,
	 * for use with 'film'.
	 */
	public function genre_init() {
		register_taxonomy(
			'film_genre',
			array( 'film' ),
			array(
				'hierarchical'          => true,
				'public'                => true,
				'show_in_nav_menus'     => true,
				'show_ui'               => true,
				'show_admin_column'     => false,
				'query_var'             => true,
				'rewrite'               => array(
					'slug'       => 'genre',
					'with_front' => false,
				),
				'capabilities'          => array(
					'manage_terms' => 'edit_posts',
					'edit_terms'   => 'edit_posts',
					'delete_terms' => 'edit_posts',
					'assign_terms' => 'edit_posts',
				),
				'labels'                => array(
					'name'                       => __( 'Genres', 'rhd' ),
					'singular_name'              => _x( 'Genre', 'taxonomy general name', 'rhd' ),
					'search_items'               => __( 'Search Genres', 'rhd' ),
					'popular_items'              => __( 'Popular Genres', 'rhd' ),
					'all_items'                  => __( 'All Genres', 'rhd' ),
					'parent_item'                => __( 'Parent Genre', 'rhd' ),
					'parent_item_colon'          => __( 'Parent Genre:', 'rhd' ),
					'edit_item'                  => __( 'Edit Genre', 'rhd' ),
					'update_item'                => __( 'Update Genre', 'rhd' ),
					'view_item'                  => __( 'View Genre', 'rhd' ),
					'add_new_item'               => __( 'Add New Genre', 'rhd' ),
					'new_item_name'              => __( 'New Genre', 'rhd' ),
					'separate_items_with_commas' => __( 'Separate Genres with commas', 'rhd' ),
					'add_or_remove_items'        => __( 'Add or remove Genres', 'rhd' ),
					'choose_from_most_used'      => __( 'Choose from the most used Genres', 'rhd' ),
					'not_found'                  => __( 'No Genres found.', 'rhd' ),
					'no_terms'                   => __( 'No Genres', 'rhd' ),
					'menu_name'                  => __( 'Genres', 'rhd' ),
					'items_list_navigation'      => __( 'Genres list navigation', 'rhd' ),
					'items_list'                 => __( 'Genres list', 'rhd' ),
					'most_used'                  => _x( 'Most Used', 'film_genre', 'rhd' ),
					'back_to_items'              => __( '&larr; Back to Genres', 'rhd' ),
				),
				'show_in_rest'          => true,
				'rest_base'             => 'genre',
				'rest_controller_class' => 'WP_REST_Terms_Controller',
			)
		);

	}

	/**
	 * Sets the post updated messages for the `film_genre` taxonomy.
	 *
	 * @param  array $messages Post updated messages.
	 * @return array Messages for the `film_genre` taxonomy.
	 */
	public function film_genre_updated_messages( $messages ) {

		$messages['film_genre'] = array(
			0 => '', // Unused. Messages start at index 1.
			1 => __( 'Genre added.', 'rhd' ),
			2 => __( 'Genre deleted.', 'rhd' ),
			3 => __( 'Genre updated.', 'rhd' ),
			4 => __( 'Genre not added.', 'rhd' ),
			5 => __( 'Genre not updated.', 'rhd' ),
			6 => __( 'Genres deleted.', 'rhd' ),
		);

		return $messages;
	}

	/**
	 * Registers the `venue` taxonomy,
	 * for use with 'post'.
	 */
	public function venue_init() {
		register_taxonomy(
			'venue',
			array( 'film', 'live_event' ),
			array(
				'hierarchical'          => true,
				'public'                => true,
				'show_in_nav_menus'     => true,
				'show_ui'               => true,
				'show_admin_column'     => true,
				'query_var'             => true,
				'rewrite'               => true,
				'capabilities'          => array(
					'manage_terms' => 'edit_posts',
					'edit_terms'   => 'edit_posts',
					'delete_terms' => 'edit_posts',
					'assign_terms' => 'edit_posts',
				),
				'labels'                => array(
					'name'                       => __( 'Venues', 'rhd' ),
					'singular_name'              => _x( 'Venue', 'taxonomy general name', 'rhd' ),
					'search_items'               => __( 'Search Venues', 'rhd' ),
					'popular_items'              => __( 'Popular Venues', 'rhd' ),
					'all_items'                  => __( 'All Venues', 'rhd' ),
					'parent_item'                => __( 'Parent Venue', 'rhd' ),
					'parent_item_colon'          => __( 'Parent Venue:', 'rhd' ),
					'edit_item'                  => __( 'Edit Venue', 'rhd' ),
					'update_item'                => __( 'Update Venue', 'rhd' ),
					'view_item'                  => __( 'View Venue', 'rhd' ),
					'add_new_item'               => __( 'Add New Venue', 'rhd' ),
					'new_item_name'              => __( 'New Venue', 'rhd' ),
					'separate_items_with_commas' => __( 'Separate Venues with commas', 'rhd' ),
					'add_or_remove_items'        => __( 'Add or remove Venues', 'rhd' ),
					'choose_from_most_used'      => __( 'Choose from the most used Venues', 'rhd' ),
					'not_found'                  => __( 'No Venues found.', 'rhd' ),
					'no_terms'                   => __( 'No Venues', 'rhd' ),
					'menu_name'                  => __( 'Venues', 'rhd' ),
					'items_list_navigation'      => __( 'Venues list navigation', 'rhd' ),
					'items_list'                 => __( 'Venues list', 'rhd' ),
					'most_used'                  => _x( 'Most Used', 'venue', 'rhd' ),
					'back_to_items'              => __( '&larr; Back to Venues', 'rhd' ),
				),
				'show_in_rest'          => true,
				'rest_base'             => 'venue',
				'rest_controller_class' => 'WP_REST_Terms_Controller',
			)
		);
	}

	/**
	 * Sets the post updated messages for the `venue` taxonomy.
	 *
	 * @param  array $messages Post updated messages.
	 * @return array Messages for the `venue` taxonomy.
	 */
	public function venue_updated_messages( $messages ) {
		$messages['venue'] = array(
			0 => '', // Unused. Messages start at index 1.
			1 => __( 'Venue added.', 'rhd' ),
			2 => __( 'Venue deleted.', 'rhd' ),
			3 => __( 'Venue updated.', 'rhd' ),
			4 => __( 'Venue not added.', 'rhd' ),
			5 => __( 'Venue not updated.', 'rhd' ),
			6 => __( 'Venues deleted.', 'rhd' ),
		);

		return $messages;
	}
}

$cpt = new Data_Types();
