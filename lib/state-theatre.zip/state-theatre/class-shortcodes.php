<?php
/**
 * Template shortcodes.
 *
 * @package RHD
 */

/**
 * Register shortcodes
 */
class Shortcodes extends RHD_Base {
	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'shortcode_init' ) );
	}

	/**
	 * Init hook.
	 *
	 * @return void
	 */
	public function shortcode_init() {
		add_shortcode( 'post-items', array( $this, 'post_items_shortcode' ) );
		add_shortcode( 'marquee', array( $this, 'marquee_heading_shortcode' ) );
		add_shortcode( 'show-poster', array( $this, 'item_poster_info_shortcode' ) );
		add_shortcode( 'show-showtimes', array( $this, 'item_showtimes_shortcode' ) );
		add_shortcode( 'featured-slider', array( $this, 'featured_slider_shortcode' ) );
	}

	/**
	 * Registers the `post-items` shortcode.
	 *
	 * @param array $atts The shortcode attributes. Should be an array of parameters for WP_Query.
	 *                    Comma-separated values will be converted into arrays.
	 * @return string The HTML output.
	 */
	public function post_items_shortcode( $atts ) {
		// phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_key
		// phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		$atts = shortcode_atts(
			array(
				'post_type'      => 'post',
				'posts_per_page' => get_option( 'posts_per_page' ),
				'slider'         => true,
				'posts_per_line' => null,
				'taxonomy'       => 'category',
				'featured'       => false, // Use the 'featured' post meta (checkbox) to query posts.
			),
			$atts,
			'post-items'
		);

		/**
		 * Save values and unset non-query args.
		 */
		$options = array(
			'slider'   => boolval( $atts['slider'] ),
			'per_line' => $atts['posts_per_line'] ? $atts['_posts_per_line'] : $atts['posts_per_page'],
			'taxonomy' => $atts['taxonomy'],
		);

		$today = new DateTime();
		$today->setTime( 23, 59, 59 );

		$args = array(
			'post_type'      => $atts['post_type'],
			'posts_per_page' => $atts['posts_per_page'],
			'post_status'    => 'publish',
			'orderby'        => 'meta_value',
			'meta_query'     => array(),
		);

		if ( stripos( $atts['post_type'], 'film' ) !== false || stripos( $atts['post_type'], 'live_event' ) !== false ) {
			$args['order']        = 'ASC';
			$args['meta_key']     = 'start_date';
			$args['meta_type']    = 'DATETIME';
			$args['meta_query'][] = array(
				'key'     => 'end_date',
				'value'   => $today->format( 'Y-m-d' ),
				'compare' => '>=',
			);
		}

		if ( $atts['featured'] ) {
			$args['meta_query'][] = array(
				array(
					'key'     => 'featured',
					'value'   => true,
					'compare' => 'LIKE',
				),
			);
		}

		$args = $this->query_args_string_to_array( $args );

		$posts = get_posts( $args );

		// Fill in remaining post slots by date.
		if ( $atts['featured'] && count( $posts ) < $atts['posts_per_page'] ) {
			// Remove 'featured' meta_query array.
			unset( $args['meta_query'] );

			// Get IDs of existing queried posts.
			$exclude_ids = array();
			foreach ( $posts as $p ) {
				$exclude_ids[] = $p->ID;
			}

			// Adjust posts_per_page.
			$args['posts_per_page'] = $args['posts_per_page'] - count( $posts );
			$args['post__not_in']   = $exclude_ids;
			$fallback_posts         = get_posts( $args );

			$posts = array_merge( $posts, $fallback_posts );
		}

		// phpcs:enable WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		// phpcs:enable WordPress.DB.SlowDBQuery.slow_db_query_meta_key

		return parent::post_items( $posts, $options );
	}

	/**
	 * Registers the `marquee` shortcode.
	 *
	 * @param array  $atts The shortcode attributes.
	 * @param string $content The enclosed shortcode content.
	 * @return string The HTML output.
	 */
	public function marquee_heading_shortcode( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'tag' => 'h2',
			),
			$atts,
			'marquee'
		);

		return sprintf(
			'<%1$s class="marquee-heading"><span class="marquee-heading__text">%2$s</span></%1$s>',
			$atts['tag'],
			$content
		);
	}

	/**
	 * Returns an img tag with the Agile thumbnail image and related data for the `film` and `live_event` post types.
	 *
	 * @param array $atts Shortcode attributes (unused).
	 * @return string The generated template HTML.
	 */
	public function item_poster_info_shortcode( $atts ) {
		if ( ! in_array( get_post_type(), array( 'film', 'live_event' ), true ) ) {
			return;
		}

		$queried_object = get_queried_object();
		if ( ! $queried_object ) {
			return;
		}

		return parent::item_template__poster( $queried_object->ID );
	}

	/**
	 * Loads the Showtimes template snippet.
	 *
	 * @param array $atts Shortcode attributes (unused).
	 * @return string The generated template HTML.
	 */
	public function item_showtimes_shortcode( $atts ) {
		$queried_object = get_queried_object();
		if ( ! $queried_object ) {
			return;
		}

		return parent::item_template__showtimes( $queried_object->ID );
	}

	/**
	 * Renders the Featured Slider.
	 *
	 * @param array $atts Shortcode attributes (unused).
	 * @return string The generated HTML template.
	 */
	public function featured_slider_shortcode( $atts ) {
		$slides = get_posts(
			array(
				'post_type'      => 'featured_slide',
				'posts_per_page' => -1,
				'post_status'    => 'publish',
			)
		);

		if ( empty( $slides ) ) {
			return;
		}

		$html = '<div class="featured-slider-container siema"><div class="featured-slider slider">';
		foreach ( $slides as $slide ) {
			$html .= '<div class="featured-slider__item">' . wp_kses_post( $slide->post_content ) . '</div>';
		}
		$html .= sprintf(
			'</div><div class="siema-nav"><button class="siema-nav__prev" href="#">%1$s</button><button class="siema-nav__next" href="#">%2$s</button></div>',
			rhd_prev_button_image(),
			rhd_next_button_image()
		);
		$html .= '</div>';

		return $html;
	}
}

$sc = new Shortcodes();
