/**
 * File frontend.js.
 *
 * Handles frontend visuals.
 *
 * @uses siema
 * @package RHD
 */

(function () {
	featuredCarousel();
	postItemCarousel();
})();

/**
 * Loops through all '.siema' instances and creates sliders.
 *
 * @returns void
 */
function postItemCarousel() {
	var allItems = document.querySelectorAll('.rhd-post-items-container.siema');
	[...allItems].forEach((item) => {
		const prev = item.querySelector('.siema-nav__prev');
		const next = item.querySelector('.siema-nav__next');
		const slider = item.querySelector('.slider');
		const siema = new Siema({
			selector: slider,
			perPage: {
				460: 1,
				768: 2,
				1024: 3,
				1200: 4,
			},
			loop: false,
		});
		const siemaCount = siema.innerElements.length;

		// Initial check.
		checkArrows(siema, prev, next);

		prev.addEventListener('click', (e) => {
			e.preventDefault();
			siema.prev();
			checkArrows(siema, prev, next);
		});

		next.addEventListener('click', (e) => {
			e.preventDefault();
			siema.next();
			checkArrows(siema, prev, next);
		});

		window.addEventListener('resize', () => {
			siema.resizeHandler();
			checkArrows(siema, prev, next);
		});
	});
}

/**
 * Creates the Featured Slider item, if present.
 *
 * @returns void
 */
function featuredCarousel() {
	const container = document.querySelector('.featured-slider-container');

	if (!container) {
		return;
	}

	const prev = container.querySelector('.siema-nav__prev');
	const next = container.querySelector('.siema-nav__next');
	const slider = container.querySelector('.slider');

	const siema = new Siema({
		selector: slider,
		perPage: 1,
		loop: true,
	});

	prev.addEventListener('click', (e) => {
		e.preventDefault();
		siema.prev();
	});
	next.addEventListener('click', (e) => {
		e.preventDefault();
		siema.next();
	});
}

/**
 * Checks if next/prev arrows should be visible.
 *
 * @param {Siema} siema The siema object.
 * @param {Node} prev The `prev` element.
 * @param {Node} next The `next` element.
 */
function checkArrows(siema, prev, next) {
	const { currentSlide, perPage } = siema;
	const count = siema.innerElements.length;

	const max = count < perPage ? count : perPage;
	const lastVisible = currentSlide + (max - 1);
	if (currentSlide === 0) {
		prev.classList.remove('visible');
	} else {
		prev.classList.add('visible');
	}

	next.classList.add('visible');

	if (lastVisible === count - 1) {
		next.classList.remove('visible');
	} else {
		next.classList.add('visible');
	}
}
