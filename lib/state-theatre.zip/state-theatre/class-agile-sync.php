<?php
/**
 * Agile Ticketing feed retrieval.
 *
 * @package RHD
 */

/**
 * Retrieves and caches data from Agile's remote services.
 */
class Agile_Sync extends RHD_Base {
	const CACHE_EXPIRE = MINUTE_IN_SECONDS * 5;

	/**
	 * The database cache key
	 *
	 * @var string
	 */
	protected $cache_key;

	/**
	 * The post type this data will be stored as.
	 *
	 * @var string
	 */
	protected $post_type;

	/**
	 * The remote URL to fetch.
	 *
	 * @var string
	 */
	private $url;

	/**
	 * The JSON-decoded remote data.
	 *
	 * @var array
	 */
	private $data;

	/**
	 * The prepared individual items.
	 *
	 * @var array
	 */
	private $items;

	/**
	 * Constructor.
	 *
	 * @param string $cache_key The cache key.
	 * @param string $post_type The post type the retrieved data will be stored as.
	 * @param string $url Agile WebSales Feed URL.
	 */
	public function __construct( $cache_key, $post_type, $url ) {
		$this->cache_key = $cache_key;
		$this->post_type = esc_attr( $post_type );
		$this->url       = $this->format_feed_url( $url );

		$this->sync_items();
	}

	/**
	 * Forces the 'format' parameter to 'json'
	 *
	 * @param string $url The URL to fetch.
	 * @return string The filtered URL.
	 */
	private function format_feed_url( $url ) {
		if ( preg_match( '/[?|&]format=/', $url ) ) {
			$url = remove_query_arg( 'format', $url );
		}
		$url = add_query_arg( 'format', 'json', $url );

		return esc_url_raw( $url );
	}

	/**
	 * DEBUG FUNCTION for printing out raw retrieved data.
	 *
	 * @return void
	 */
	public function print_raw_data() {
		printf( '<pre>%s</pre>', print_r( $this->data, true ) ); // phpcs:ignore
	}

	/**
	 * Getter for $items property.
	 *
	 * @return array The $items property.
	 */
	public function get_items() {
		return $this->items;
	}

	/**
	 * Fetch a feed.
	 *
	 * @return void
	 */
	private function fetch_feed() {
		$item_data = get_transient( $this->cache_key );
		if ( false === $item_data ) {
			// Fetch from source.
			$response  = wp_remote_get( $this->url );
			$item_data = json_decode( $response['body'], true );

			set_transient( $this->cache_key, $item_data['ArrayOfShows'], self::CACHE_EXPIRE );
			$this->data = $item_data['ArrayOfShows'];
		} else {
			$this->data = $item_data;
		}
	}

	/**
	 * Undocumented function
	 *
	 * @return void
	 */
	private function prepare_items() {
		$prepared_items = array();

		foreach ( $this->data as $item_data ) {
			$prepared_items[] = new Agile_Item( $item_data, $this->post_type );
		}

		$this->items = $prepared_items;
	}

	/**
	 * Checks for matching posts with matching `agile_show_id` meta value to update.
	 *
	 * @return void
	 */
	public function update_posts() {
		// Unhook to prevent infinite loop.
		remove_action( 'save_post_film', 'rhd_agile_sync_remote_post' );
		remove_action( 'save_post_live_event', 'rhd_agile_sync_remote_post' );

		foreach ( $this->items as $item ) {
			$this->update_post( $item );
		}

		// Re-hook.
		add_action( 'save_post_film', 'rhd_agile_sync_remote_post', 10, 1 );
		add_action( 'save_post_live_event', 'rhd_agile_sync_remote_post', 10, 1 );
	}

	/**
	 * Updates the post with remote item data.
	 *
	 * @param Agile_Item $item The item to update.
	 * @return int|false The post ID on success; false on failure.
	 */
	public function update_post( $item ) {
		if ( ! $item->post_id ) {
			return false;
		}

		$postarr = array_merge( $item->get_prepared_item(), array( 'ID' => $item->post_id ) );

		if ( isset( $postarr['tax_input'] ) ) {
			$taxonomies = $postarr['tax_input'];
			unset( $postarr['tax_input'] );

			if ( $taxonomies ) {
				foreach ( $taxonomies as $taxonomy => $terms ) {
					wp_set_object_terms( $item->post_id, $terms, $taxonomy, false );
				}
			}
		}

		$result = wp_update_post( $postarr );

		return 0 !== $result ? $result : false;
	}

	/**
	 * Update items in the database with filtered Agile data.
	 *
	 * @return void
	 */
	public function sync_items() {
		$this->fetch_feed();
		$this->prepare_items();
		$this->update_posts();
	}
}
