<?php
/**
 * Template for a single `film` or `live_event` item's showtimes and associated purchase links.
 *
 * Must be used in the Loop.
 *
 * @uses $args[] The arguments passed from load_template().
 *
 * @package RHD
 */

if ( 'film' === get_post_type() ) {
	$event_itemtype = 'https://schema.org/ScreeningEvent';
} elseif ( 'live_event' === get_post_type() ) {
	$event_itemtype = 'https://schema.org/TheaterEvent';
}
?>

<div class="showtimes">
	<?php if ( isset( $args['showtimes'] ) && $args['showtimes'] ) : ?>
		<ul class="showtimes__list">
			<?php foreach ( $args['showtimes'] as $showtime ) : ?>
				<?php $class = $showtime['start'] < new DateTime("now", wp_timezone() ) ? 'past' : 'future'; ?>
				<li itemscope itemtype="<?php echo $event_itemtype; ?>" class="showtime <?php echo esc_attr( $class ); ?>">

					<?php $item_purchase_link = $args['purchase_link__external'] === true ? esc_url( $args['purchase_link'] ) : esc_url( $showtime['purchase_link'] ); ?>

					<span itemprop="name" content="<?php the_title(); ?>"></span>
					<span itemprop="organizer" itemscope itemtype="https://schema.org/Organization">
						<span itemprop="name" content="<?php bloginfo( 'name' ); ?>"></span>
						<span itemprop="url" content="<?php echo home_url(); ?>"></span>
					</span>
					<span itemprop="offers" itemscope itemtype="https://schema.org/Offer">
						<span itemprop="url" content="<?php echo $item_purchase_link; ?>"></span>
					</span>
					<span itemprop="eventAttendanceMode" content="https://schema.org/OfflineEventAttendanceMode"></span>
					<span itemprop="image" content="<?php echo esc_url( RHD_Base::post_main_image_url() ); ?>"></span>
					<span itemprop="description" content="<?php echo wp_strip_all_tags( get_the_excerpt() ); ?>"></span>
					<span itemprop="eventStatus" content="https://schema.org/EventScheduled"></span>
					<?php if ( 'live_event' === get_post_type() ) : ?>
						<span itemprop="performer" content="<?php the_title(); ?>"></span>
					<?php endif; ?>

					<p itemprop="startDate" content="<?php echo $showtime['start']->format( 'c' ); ?>" class="showtime__date"><?php echo wp_kses_post( $showtime['start']->format( 'l M. j, Y' ) ); ?></p>
					<p class="showtime__info">
						<span itemprop="location" itemscope itemtype="https://schema.org/Place" class="venue">
							<span itemprop="name"><?php echo wp_kses_post( $showtime['venue'] ); ?></span>
							<span itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">
								<span itemprop="streetAddress" content="<?php echo wp_kses_post( $args['venue_address']['street'] ); ?>"></span>
								<span itemprop="addressLocality" content="<?php echo wp_kses_post( $args['venue_address']['city'] ); ?>"></span>
								<span itemprop="addressRegion" content="<?php echo wp_kses_post( $args['venue_address']['state'] ); ?>"></span>
								<span itemprop="postalCode" content="<?php echo wp_kses_post( $args['venue_address']['zip'] ); ?>"></span>
							</span>
						</span>
						<span class="time"><a href="<?php echo $item_purchase_link; ?>"><?php echo wp_kses_post( $showtime['start']->format( 'g:i A' ) ); ?></a></span>
					</p>

				</li>
			<?php endforeach; ?>
		</ul>

		<?php if ( $args['purchase_link'] ) : ?>
			<span itemprop="offer" itemscope itemtype="https://schema.org/Offer">
				<a itemprop="url" class="button purchase-link" href="<?php echo esc_url( $args['purchase_link'] ); ?>" target="_blank"><?php esc_html_e( 'Buy Tickets', 'rhd' ); ?></a>
			</span>
		<?php else : ?>
			<p><?php _e( 'This show has passed.', 'rhd' ); ?></p>
		<?php endif; ?>
	
	<?php else : ?>
		<h4><?php _e( 'No showtimes available.', 'rhd' ); ?></h4>
	<?php endif; ?>
</div>
