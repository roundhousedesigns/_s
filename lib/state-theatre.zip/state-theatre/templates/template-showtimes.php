<?php
/**
 * Template for a single `film` or `live_event` item's showtimes and associated purchase links.
 *
 * Must be used in the Loop.
 *
 * @uses $args[] The arguments passed from load_template().
 *
 * @package RHD
 */

?>

<div class="showtimes">
	<?php if ( isset( $args['showtimes'] ) && $args['showtimes'] ) : ?>
		<ul class="showtimes__list">
			<?php foreach ( $args['showtimes'] as $showtime ) : ?>
				<?php $class = $showtime['date'] < new DateTime("now", wp_timezone() ) ? 'past' : 'future'; ?>
				<li class="showtime <?php echo esc_attr( $class ); ?>">
					<p class="showtime__date"><?php echo wp_kses_post( $showtime['date']->format( 'l M. j, Y' ) ); ?></p>
					<p class="showtime__info">
						<span class="venue"><?php echo wp_kses_post( $showtime['venue'] ); ?></span>
						<span class="time"><a href="<?php echo $args['purchase_link__external'] === true ? esc_url( $args['purchase_link'] ) : esc_url( $showtime['purchase_link'] ); ?>"><?php echo wp_kses_post( $showtime['date']->format( 'g:i A' ) ); ?></a></span>
					</p>
				</li>
			<?php endforeach; ?>
		</ul>

		<?php if ( $args['purchase_link'] ) : ?>
			<a class="button purchase-link" href="<?php echo esc_url( $args['purchase_link'] ); ?>" target="_blank"><?php esc_html_e( 'Buy Tickets', 'rhd' ); ?></a>
		<?php endif; ?>
	
	<?php else : ?>
	
		<h4><?php _e( 'This show has passed.', 'rhd' ); ?></h4>
	
	<?php endif; ?>
</div>
