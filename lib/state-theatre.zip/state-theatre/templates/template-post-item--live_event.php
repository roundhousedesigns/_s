<?php // phpcs:ignore WordPress.Files.FileName.NotHyphenatedLowercase
/**
 * Displays a `live_event` post item.
 *
 * Must be used in the Loop.
 *
 * @uses $args[] The arguments passed from load_template().
 *
 * @package RHD
 */

?>

<div class="post-item">
	<header class="post-item__header">
		<?php RHD_Base::post_main_image(); ?>

		<?php if ( isset( $args['primary_taxonomy'] ) && ! empty( $args['primary_taxonomy'] ) ) : ?>
			<a class="post-item-taxonomy-link <?php echo esc_attr( $args['primary_taxonomy']['taxonomy'] ); ?>" href="<?php echo esc_url( $args['primary_taxonomy']['permalink'] ); ?>" rel="bookmark"><?php echo wp_kses_post( $args['primary_taxonomy']['name'] ); ?></a>
		<?php endif; ?>

		<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '<h3 class="post-item-title entry-title">', '</h3>' ); ?></a>
	</header>
	<div class="post-item__content">
		<div class="post-item-date">
			<?php RHD_Base::film_event_item_date(); ?>
		</div>
	</div>
</div>
