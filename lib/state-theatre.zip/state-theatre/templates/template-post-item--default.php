<?php
/**
 * Displays a post item.
 *
 * Must be used in the Loop.
 *
 * @uses $args[] The arguments passed from load_template().
 *
 * @package RHD
 */

$post_classes = array_merge( array( 'post-item' ), $args['classes'] );
$date = in_array( get_post_type(), array( 'film', 'live_event' ), true ) ? RHD_Base::film_event_item_date() : get_the_date();
?>

<div class="<?php echo implode( ' ', $post_classes ); ?>">
	<header class="post-item__header">
		<?php RHD_Base::post_main_image(); ?>

		<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '<h3 class="post-item-title">', '</h3>' ); ?></a>
	</header>
	<div class="post-item__content">
		<div itemprop="startDate" class="post-item-date">
			<?php echo $date; ?>
		</div>

		<?php if ( $args['excerpt'] ) : ?>
			<div class="post-item__excerpt">
				<?php the_excerpt(); ?>
			</div>
		<?php endif; ?>
	</div>
</div>
