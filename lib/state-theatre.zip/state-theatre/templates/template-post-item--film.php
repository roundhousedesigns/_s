<?php // phpcs:ignore WordPress.Files.FileName.NotHyphenatedLowercase
/**
 * Displays a `film` post item.
 *
 * Must be used in the Loop.
 *
 * @uses $args[] The arguments passed from load_template().
 *
 * @package RHD
 */

$post_classes = array_merge( array( 'post-item' ), $args['classes'] );
$start_date = get_post_meta( get_the_id(), 'start_date', true );
if ( ! $start_date ) {
	error_log('nar');
}
$end_date = get_post_meta( get_the_id(), 'end_date', true );
$venue_address = array(
	'street' => get_option( 'rhd_options' )['venue_address_street'],
	'city'   => get_option( 'rhd_options' )['venue_address_city'],
	'state'  => get_option( 'rhd_options' )['venue_address_state'],
	'zip'    => get_option( 'rhd_options' )['venue_address_zip'],
);
?>

<div itemscope itemtype="https://schema.org/ScreeningEvent" class="<?php echo implode( ' ', $post_classes ); ?>">
	<header class="post-item__header">

		<!-- structured data -->
		<span itemprop="name" content="<?php the_title(); ?>"></span>
		<span itemprop="image" content="<?php echo RHD_Base::post_main_image_url(); ?>"></span>
		<span itemprop="description" content="<?php echo get_the_excerpt(); ?>"></span>
		<span itemprop="startDate" content="<?php echo $start_date; ?>"></span>
		<span itemprop="endDate" content="<?php echo $end_date; ?>"></span>
		<span itemprop="location" itemscope itemtype="https://schema.org/Place" class="venue">
			<span itemprop="name" content="<?php bloginfo( 'name' ); ?>"></span>
			<span itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">
				<span itemprop="streetAddress" content="<?php echo wp_kses_post( $venue_address['street'] ); ?>"></span>
				<span itemprop="addressLocality" content="<?php echo wp_kses_post( $venue_address['city'] ); ?>"></span>
				<span itemprop="addressRegion" content="<?php echo wp_kses_post( $venue_address['state'] ); ?>"></span>
				<span itemprop="postalCode" content="<?php echo wp_kses_post( $venue_address['zip'] ); ?>"></span>
			</span>
		</span>
		<span itemprop="eventAttendanceMode" content="https://schema.org/OfflineEventAttendanceMode"></span>
		<span itemprop="eventStatus" content="https://schema.org/EventScheduled"></span>
		<span itemprop="organizer" itemscope itemtype="https://schema.org/Organization">
			<span itemprop="name" content="<?php bloginfo( 'name' ); ?>"></span>
			<span itemprop="url" content="<?php echo home_url(); ?>"></span>
		</span>
		<!-- /structured-data -->

		<?php RHD_Base::post_main_image(); ?>

		<?php if ( isset( $args['primary_taxonomy'] ) && ! empty( $args['primary_taxonomy'] ) ) : ?>
			<a class="post-item-taxonomy-link type-film <?php echo esc_attr( $args['primary_taxonomy']['taxonomy'] ); ?>" href="<?php echo esc_url( $args['primary_taxonomy']['permalink'] ); ?>" rel="bookmark"><?php echo wp_kses_post( $args['primary_taxonomy']['name'] ); ?></a>
		<?php endif; ?>

		<span itemprop="offers" itemscope itemtype="https://schema.org/AggregateOffer">
			<a itemprop="url" href="<?php the_permalink(); ?>" rel="bookmark">
				<h3 class="post-item-title"><?php the_title(); ?></h3>
			</a>
		</span>
	</header>
	<div class="post-item__content">
		<div class="post-item-date">
			<?php echo RHD_Base::film_event_item_date(); ?>
		</div>
	</div>
</div>
