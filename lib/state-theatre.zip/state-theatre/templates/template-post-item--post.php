<?php
/**
 * Displays a post item.
 *
 * Must be used in the Loop.
 *
 * @uses $args[] The arguments passed from load_template().
 *
 * @package RHD
 */

$post_classes = array_merge( array( 'post-item' ), $args['classes'] );
?>

<div itemscope itemtype="https://schema.org/Article" class="<?php echo implode( ' ', $post_classes ); ?>">
	<header class="post-item__header">
		<span itemprop="image" content="<?php echo RHD_Base::post_main_image_url(); ?>"></span>
		<span itemprop="author" content="<?php bloginfo( 'name' ); ?>"></span>
		<span itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
			<span itemprop="name" content="<?php bloginfo( 'name' ); ?>"></span>
			<span itemprop="url" content="<?php echo home_url(); ?>"></span>
		</span>

		<?php RHD_Base::post_main_image(); ?>

		<a itemprop="mainEntityOfPage" content="<?php the_permalink(); ?>" href="<?php the_permalink(); ?>" rel="bookmark">
			<h3 itemprop="headline" class="post-item-title"><?php the_title(); ?></h3>
		</a>
	</header>
	<div class="post-item__content">
		<div itemprop="datePublished" class="post-item-date">
			<?php echo get_the_date(); ?>
			<span itemprop="dateModified" content="<?php the_modified_date( 'c' ); ?>"></span>
		</div>

		<div class="post-item__excerpt" itemprop="description">
			<?php the_excerpt(); ?>
		</div>
	</div>
</div>
