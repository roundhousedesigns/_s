<?php
/**
 * Template for a single `film` or `live_event` item's sidebar poster heading.
 *
 * Must be used in the Loop.
 *
 * @uses $args[] The arguments passed from load_template().
 *
 * @package RHD
 */

?>
<div class="poster-info">
	<figure class="film-live_event-poster">
		<img src="<?php echo esc_url( $args['image'] ); ?>">

		<?php if ( 'film' === get_post_type() ) : ?>
			<figcaption>
				<span class="release">
					<?php echo esc_textarea( $args['release'] ); ?>
				</span>
				<span class="length">
					<?php printf( '%s min', esc_textarea( $args['length'] ) ); ?>
				</span>
				<span class="rating">
					<?php printf( 'Rated %s', wp_kses_post( implode( '<br />', $args['rating'] ) ) ); ?>
				</span>
			</figcaption>
		<?php endif; ?>
</div>
