<?php
/**
 * Plugin Name: State Theatre
 * Description: Data types, Agile Ticketing, shortcodes, and more.
 * Author: Roundhouse Designs
 * Author URI: https://roundhouse-designs.com
 *
 * @package RHD
 */

/**
 * Constants.
 */
define( 'RHD_AGILE_KEY_PREFIX', 'rhd_agile_' );
define( 'RHD_AGILE_KEY__FILM', RHD_AGILE_KEY_PREFIX . '_film' );
define( 'RHD_AGILE_KEY__LIVE_EVENT', RHD_AGILE_KEY_PREFIX . '_event' );
define( 'AGILE_FEED_URL__FILM', 'https://prod5.agileticketing.net/websales/feed.ashx?guid=2b760ca4-a6e6-4217-ac05-0149aa8294f5&showslist=true&fulldescription=true&withmedia=true&format=json&v=latest&' );
define( 'AGILE_FEED_URL__LIVE_EVENT', 'https://prod5.agileticketing.net/websales/feed.ashx?guid=95803ce7-2f6a-453a-907a-38e1e556264d&showslist=true&fulldescription=true&withmedia=true&format=json&v=latest&' );
define( 'AGILE_FEED_URL__ALL', 'https://prod5.agileticketing.net/websales/feed.ashx?guid=63f62f62-2e4b-4e83-ac8a-8f987e373670&showslist=true&fulldescription=true&withmedia=true&format=json&v=latest&' );

// Load modules.
require_once plugin_dir_path( __FILE__ ) . 'class-rhd-base.php';
require_once plugin_dir_path( __FILE__ ) . 'class-data-types.php';
require_once plugin_dir_path( __FILE__ ) . 'class-shortcodes.php';

// Agile classes.
require_once plugin_dir_path( __FILE__ ) . 'class-agile-item.php';
require_once plugin_dir_path( __FILE__ ) . 'class-agile-sync.php';

/**
 * Activation hook.
 *
 * @return void
 */
function rhd_site_base_plugin_activation() {
	// Sync immediately.
	rhd_agile_sync( true );

	// Schedule periodic refresh.
	wp_schedule_event( time(), 'every15minutes', 'rhd_schedule_agile_sync' );

	// Rewrite permalinks.
	// TODO This fires BEFORE CPTs are registered, making it useless. FIX ME.
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'rhd_site_base_plugin_activation' );

/**
 * Deactivation hook.
 *
 * @return void
 */
function rhd_site_base_plugin_deactivation() {
	// Unschedule interval sync.
	$timestamp = wp_next_scheduled( 'rhd_agile_sync' );
	wp_unschedule_event( $timestamp, 'rhd_agile_sync' );

	// Clear transients and things.
	rhd_cleanup();

	// Rewrite permalinks.
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'rhd_site_base_plugin_deactivation' );

/**
 * Enqueue scripts and styles.
 *
 * @return void
 */
function rhd_state_theatre_enqueue() {
	wp_register_script( 'siema', plugin_dir_url( __FILE__ ) . '/js/vendor/siema/dist/siema.min.js', array(), '1.5.1', true );
	wp_enqueue_script( 'state-theatre-frontend', plugin_dir_url( __FILE__ ) . '/js/frontend.js', array( 'siema' ), RHD_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'rhd_state_theatre_enqueue' );

/**
 * Register custom cron intervals.
 *
 * @param array $schedules An array of non-default cron schedules. Default empty.
 * @return array The adjusted cron intervals.
 */
function rhd_agile_sync_intervals( $schedules ) {
	$schedules['every15minutes'] = array(
		'interval' => 900,
		'display'  => __( 'Every 15 minutes' ),
	);

	return $schedules;
}
add_filter( 'cron_schedules', 'rhd_agile_sync_intervals' );

/**
 * Schedules Agile feed cron job.
 *
 * @return void
 */
function rhd_agile_sync() {
	$films  = new Agile_Sync( RHD_AGILE_KEY__FILM, 'film', AGILE_FEED_URL__FILM );
	$events = new Agile_Sync( RHD_AGILE_KEY__LIVE_EVENT, 'live_event', AGILE_FEED_URL__LIVE_EVENT );
}
add_action( 'rhd_schedule_agile_sync', 'rhd_agile_sync' );

/**
 * Cleanup on plugin deactivation.
 *
 * @return void
 */
function rhd_cleanup() {
	delete_transient( AGILE_FEED_URL__FILM );
	delete_transient( AGILE_FEED_URL__LIVE_EVENT );
}

/**
 * Synchronizes remote data for one Agile show.
 *
 * @param int $post_id The post ID.
 * @return void
 */
function rhd_agile_sync_remote_post( $post_id ) {
	$post_type     = get_post_type( $post_id );
	$agile_show_id = get_post_meta( $post_id, 'agile_show_id', true );

	if ( ! $agile_show_id ) {
		return;
	}

	$remote_post = new Agile_Sync( RHD_AGILE_KEY_PREFIX . $post_id, $post_type, AGILE_FEED_URL__ALL . "showid=${agile_show_id}", true );

	$remote_post->update_posts();
}
add_action( 'save_post_film', 'rhd_agile_sync_remote_post' );
add_action( 'save_post_live_event', 'rhd_agile_sync_remote_post' );

/**
 * Gets the "next" button image.
 *
 * @return string The image src.
 */
function rhd_next_button_image() {
	return '<svg width="22px" height="38px" viewBox="0 0 22 38" version="1.1"
			xmlns="http://www.w3.org/2000/svg"
			xmlns:xlink="http://www.w3.org/1999/xlink">
			<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
					<g transform="translate(-976.000000, -456.000000)" fill="#FFFFFF">
							<path d="M1001.24435,465.072482 L986.713102,479.447482 L972.181852,465.072482 C971.036013,463.822472 969.890191,463.796432 968.744352,464.994352 C967.598513,466.192282 967.598513,467.364142 968.744352,468.509982 L984.994352,484.759982 C985.411022,485.280818 985.983932,485.541232 986.713102,485.541232 C987.442272,485.541232 988.015182,485.280818 988.431852,484.759982 L1004.68185,468.509982 C1005.82769,467.364142 1005.82769,466.192282 1004.68185,464.994352 C1003.53601,463.796432 1002.39019,463.822472 1001.24435,465.072482 Z" transform="translate(986.713102, 474.828130) rotate(-90.000000) translate(-986.713102, -474.828130) "></path>
					</g>
			</g>
	</svg>';
}

/**
 * Gets the "previous" button image.
 *
 * @return string The image src.
 */
function rhd_prev_button_image() {
	return '<svg width="22px" height="38px" viewBox="0 0 22 38" version="1.1"
		xmlns="http://www.w3.org/2000/svg"
		xmlns:xlink="http://www.w3.org/1999/xlink">
		<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
				<g transform="translate(-23.000000, -456.000000)" fill="#FFFFFF">
						<path d="M48.2443518,465.072482 L33.7131018,479.447482 L19.1818518,465.072482 C18.0360128,463.822472 16.8901908,463.796432 15.7443518,464.994352 C14.5985127,466.192282 14.5985127,467.364142 15.7443518,468.509982 L31.9943518,484.759982 C32.4110218,485.280818 32.9839318,485.541232 33.7131018,485.541232 C34.4422718,485.541232 35.0151818,485.280818 35.4318518,484.759982 L51.6818518,468.509982 C52.8276918,467.364142 52.8276918,466.192282 51.6818518,464.994352 C50.5360118,463.796432 49.3901918,463.822472 48.2443518,465.072482 Z" transform="translate(33.713102, 474.828130) rotate(-270.000000) translate(-33.713102, -474.828130) "></path>
				</g>
		</g>
	</svg>';
}
