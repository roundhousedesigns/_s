<?php
/**
 * Initializes site functions.
 *
 * @package RHD
 */

/**
 * The base theme class
 */
class RHD_Base {
	/**
	 * Singleton
	 *
	 * @var RHD_Base
	 */
	private static $instance = null;

	/**
	 * Template directory path.
	 *
	 * @var string
	 */
	private static $template_dir;

	/**
	 * Agile_Sync feeds.
	 *
	 * @var array
	 */
	public $feeds;

	/**
	 * Constructor.
	 */
	private function __construct() {
		self::$template_dir = plugin_dir_path( __FILE__ ) . 'templates/';
	}

	/**
	 * Bootstrap the class
	 *
	 * @return RHD_Base
	 */
	public static function init() {
		if ( ! self::$instance ) {
			self::$instance = new RHD_Base();
		}

		return self::$instance;
	}

	/**
	 * Loads a template.
	 *
	 * @param string $template_slug The template slug. Templates are located in the `templates/` directory.
	 * @param array  $args Arguments to pass to the template.
	 * @return string The template HTML output.
	 */
	private static function load_template( $template_slug, $args = array() ) {
		ob_start();
		load_template( self::$template_dir . $template_slug, false, $args );
		return ob_get_clean();
	}

	/**
	 * HTML item template. Must be called in the Loop.
	 *
	 * @param boolean $excerpt True to display the excerpt. Defaults to `false`.
	 * @param array   $post_class Additional post classes.
	 * @return string The HTML template.
	 */
	public static function item_template__default( $excerpt = false, $post_class = array() ) {
		$args = array(
			'excerpt' => $excerpt,
			'classes' => $post_class,
		);

		return self::load_template( 'template-post-item--default.php', $args );
	}

	/**
	 * HTML item template. Must be called in the Loop.
	 *
	 * @param string  $post_type The post type.
	 * @param string  $taxonomy The taxonomy to use for the primary category link.
	 *                         Defaults to ''.
	 * @param boolean $excerpt True to display the excerpt. Defaults to `false`.
	 * @param array   $post_class Additional post classes.
	 * @return string The HTML template.
	 */
	public static function item_template__post( $post_type, $taxonomy = '', $excerpt = false, $post_class = array() ) {
		$primary_taxonomy = self::primary_taxonomy_link( $taxonomy );
		$args             = array(
			'primary_taxonomy' => $primary_taxonomy,
			'excerpt'          => $excerpt,
			'classes'          => $post_class,
		);

		return self::load_template( "template-post-item--${post_type}.php", $args );
	}

	/**
	 * HTML poster template for `film` and `live_event` posts.
	 *
	 * @param int $id The post id.
	 * @return string The HTML template.
	 */
	public function item_template__poster( $id ) {
		$args = array(
			'image'   => get_post_meta( $id, 'agile_image_thumb', true ),
			'release' => get_post_meta( $id, 'release_year', true ),
			'length'  => get_post_meta( $id, 'duration', true ),
			'rating'  => get_post_meta( $id, 'rating', true ),
		);

		return self::load_template( 'template-poster-info.php', $args );
	}

	/**
	 * HTML item template. Must be called in the Loop.
	 *
	 * @param int $id The post id.
	 * @return string The HTML template.
	 */
	public static function item_template__showtimes( $id ) {
		$external_purchase_link = get_post_meta( $id, 'external_purchase_link', true );

		$args = array(
			'showtimes'               => get_post_meta( $id, 'showtimes', true ),
			'purchase_link'           => $external_purchase_link ? $external_purchase_link : (
				self::all_shows_in_past( $id ) ? false : get_post_meta( $id, 'purchase_link', true ) ),
			'purchase_link__external' => $external_purchase_link ? true : false,
		);

		return self::load_template( 'template-showtimes.php', $args );
	}

	/**
	 * HTML item template. Must be called in the Loop.
	 *
	 * @param WP_Post $slide The `featured_slider` post.
	 * @return string The HTML template.
	 */
	public static function item_template__featured_slider( $slide ) {
		$content = apply_filters( 'the_content', $slide->post_content );

		return sprintf( '<div class="featured_slider__slide">%1$s</div>', $content );
	}

	/**
	 * Generates a category link. If Yoast is installed, gets the primary category. Otherwise, the first found.
	 *
	 * @param string   $taxonomy The taxonomy slug to check.
	 * @param int|null $id The post ID.
	 *
	 * @return array The term name and permalink.
	 */
	public static function primary_taxonomy_link( $taxonomy, $id = null ) {
		$id = $id ? $id : get_the_id();

		$primary_term_id = null;
		$primary_term    = null;
		if ( function_exists( 'yoast_get_primary_term_id' ) ) {
			$primary_term_id = yoast_get_primary_term_id( $taxonomy, $id );
		}

		if ( $primary_term_id ) {
			$primary_term = get_term( $primary_term_id, $taxonomy );
		} else {
			$terms = wp_get_post_terms( $id, $taxonomy );

			if ( $terms ) {
				$primary_term = $terms[0];
			}
		}

		if ( ! $primary_term || is_wp_error( $primary_term ) ) {
			return;
		}

		return array(
			'permalink' => get_term_link( $primary_term ),
			'name'      => $primary_term->name,
			'taxonomy'  => $taxonomy,
		);
	}

	/**
	 * Generates an item feed based on an array of WP_Query parameters.
	 *
	 * @param array $posts The queried posts.
	 * @param array $options Output and display options.
	 *
	 * @return string The HTML output.
	 */
	public static function post_items( $posts, $options ) {
		$html = '';
		global $post;

		$container_classes   = array( 'rhd-post-items-container' );
		$container_classes[] = isset( $options['slider'] ) && $options['slider'] ? 'siema' : '';
		$list_classes        = isset( $options['list_classes'] ) ? $options['list_classes'] : array();
		$list_classes[]      = 'rhd-post-items post-items slider';
		$list_classes[]      = 'post-items_' . $options['per_line'];

		$taxonomy = isset( $options['taxonomy'] ) ? $options['taxonomy'] : '';

		if ( $posts ) {
			$html .= sprintf( '<div class="%1$s"><div class="%2$s">', implode( ' ', $container_classes ), implode( ' ', $list_classes ) );
			foreach ( $posts as $post ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
				setup_postdata( $post );

				$html .= self::item_template__post( get_post_type( $post ), $taxonomy );
			}
			wp_reset_postdata();
		}

		$slider_nav = sprintf(
			'<div class="siema-nav"><button class="siema-nav__prev" href="#">%1$s</button><button class="siema-nav__next" href="#">%2$s</button></div>',
			rhd_prev_button_image(),
			rhd_next_button_image()
		);

		$html .= '</div>';
		$html .= $options['slider'] ? $slider_nav : '';
		$html .= '</div>';

		return $html;
	}

	/**
	 * Explodes comma-separated strings into arrays for use as WP_Query parameters.
	 *
	 * @param array $args WP_Query parameters.
	 *
	 * @return array The filtered array.
	 */
	public function query_args_string_to_array( $args ) {
		foreach ( $args as $key => $value ) {
			if ( gettype( $value ) === 'string' ) {
				if ( strpos( $value, ',' ) ) {
					$args[$key] = explode( ',', $value ); // phpcs:ignore WordPress.Arrays.ArrayKeySpacingRestrictions.NoSpacesAroundArrayKeys
				}
			}
		}

		return $args;
	}

	/**
	 * Ensures a date is a DateTime object.
	 *
	 * @param mixed $date The date to check.
	 * @return DateTime A valid DateTime object.
	 */
	public static function sanitize_datetime( $date ) {
		if ( $date instanceof DateTime ) {
			return $date;
		} elseif ( gettype( $date ) === 'string' ) {
			return new DateTime( $date, wp_timezone() );
		}
	}

	/**
	 * Formats a `film` or `live_event`s date fields to one line.
	 *
	 * @param int|null $id The post ID.
	 * @return void
	 */
	public static function film_event_item_date( $id = null ) {
		$id     = $id ? $id : get_the_id();
		$format = 'M. j, Y';

		$start = get_post_meta( $id, 'start_date', true );
		$end   = get_post_meta( $id, 'end_date', true );

		// Typecasting.
		$start = self::sanitize_datetime( $start );
		$end   = self::sanitize_datetime( $end );

		if ( ! $start ) {
			return;
		}

		$date = '';

		if ( ! $end || $start->format( $format ) === $end->format( $format ) ) {
			$date = $start->format( $format );
		} else {
			// Format for the same month.
			if ( $start->format( 'Y-m' ) === $end->format( 'Y-m' ) ) {
				$date = sprintf(
					'%1$s %2$s - %3$s, %4$s',
					$start->format( 'M.' ),
					$start->format( 'j' ),
					$end->format( 'j' ),
					$end->format( 'Y' )
				);
			} else {
				$date = sprintf( '%1$s - %2$s', $start->format( $format ), $end->format( $format ) );
			}
		}

		printf( wp_kses( $date, 'post' ) );
	}

	/**
	 * Gets the post thumbnail, or if not present, the Agile image thumb
	 *
	 * @param int|null $id The post ID.
	 * @return void
	 */
	public static function post_main_image( $id = null ) {
		$id = $id ? $id : get_the_id();

		$thumb     = null;
		$agile_src = get_post_meta( $id, 'agile_image_thumb', true );
		if ( has_post_thumbnail( $id ) ) {
			$thumb = get_the_post_thumbnail( $id, 'poster' );
		} elseif ( $agile_src ) {
			$thumb = sprintf( '<img src="%s" class="agile-image-thumb" />', esc_url( $agile_src ) );
		} else {
			$fallback = get_option( 'rhd_options' )['fallback_thumb'];
			$thumb    = wp_get_attachment_image( $fallback, 'thumb', false );
		}

		$html = '';
		if ( $thumb ) {
			$html = sprintf( '<a class="post-item-image-link" href="%s">%s</a>', get_the_permalink( $id ), $thumb );
		}

		printf( '%s', wp_kses( $html, 'post' ) );
	}

	/**
	 * Checks if a `film` or `live_event` post is in the past by seeing if "now" is past
	 * the final show's start date (time).
	 *
	 * @param int $id The post ID.
	 * @return boolean True if this is show happened in the past, false otherwise or on error.
	 */
	public static function all_shows_in_past( $id ) {
		$last_showing_start = get_post_meta( $id, 'last_showing_start', true );
		$showtimes          = get_post_meta( $id, 'showtimes', true );

		if ( ! $last_showing_start && ! $showtimes ) {
			return false;
		}

		$tz  = wp_timezone();
		$now = new DateTime( "now", $tz );

		if ( $last_showing_start ) {
			$last_showing_start = new DateTime( $last_showing_start, $tz );
		} else {
			if ( 'array' === gettype( $showtimes ) ) {
				$index              = count( $showtimes ) - 1;
				$last_showing_start = $showtimes[$index]['EndDate'];
			}
		}

		if ( $last_showing_start < $now ) {
			return true;
		}

		return false;
	}
}

$rhd_theme = RHD_Base::init();
