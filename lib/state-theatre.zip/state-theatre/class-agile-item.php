<?php
/**
 * Agile show item.
 *
 * @package RHD
 */

/**
 * Retrieves and caches data from Agile's remote services.
 */
class Agile_Item extends RHD_Base {
	/**
	 * The unique Agile show ID.
	 *
	 * @var int
	 */
	private $agile_show_id;

	/**
	 * The raw event data.
	 *
	 * @var array
	 */
	private $agile_data;

	/**
	 * The post type as which this Agile show should be stored.
	 *
	 * @var string
	 */
	public $post_type;

	/**
	 * The post ID associated with this Agile show.
	 *
	 * @var int
	 */
	public $post_id;

	/**
	 * The filtered event data.
	 *
	 * @var array
	 */
	protected $prepared_item;

	/**
	 * Constructor.
	 *
	 * @param array  $agile_data The raw item data.
	 * @param string $post_type The post type as which this event should be stored.
	 */
	public function __construct( $agile_data, $post_type ) {
		$this->agile_show_id = $agile_data['ID'];
		$this->agile_data    = $agile_data;
		$this->post_type     = $post_type;

		$this->prepare_item();
	}

	/**
	 * Getter for the $prepared_item property.
	 *
	 * @return array The item data.
	 */
	public function get_prepared_item() {
		return $this->prepared_item;
	}

	/**
	 * Setter for the $prepared_item property.
	 *
	 * @param array $data The prepared data.
	 * @return void
	 */
	private function set_prepared_item( $data ) {
		$this->prepared_item = $data;
	}

	/**
	 * Filters item data to an array acceptable by `wp_update_post`.
	 *
	 * @return void
	 */
	protected function prepare_item() {
		$dates          = $this->get_showings_date_range();
		$start_date_obj = new DateTime( $dates['start_date'] );

		$prepared_item = array(
			'post_type'    => $this->post_type,
			'post_title'   => $this->agile_data['Name'],
			'post_name'    => sanitize_title( $this->agile_data['Name'] . '-' . $start_date_obj->format( 'mY' ) ),
			'post_content' => isset( $this->agile_data['FullDescription'] ) ? $this->agile_data['FullDescription'] : '',
			'post_excerpt' => isset( $this->agile_data['ShortDescription'] ) ? $this->agile_data['ShortDescription'] : '',
			'meta_input'   => array(
				'agile_show_id'      => $this->agile_show_id,
				'duration'           => $this->agile_data['Duration'],
				'purchase_link'      => esc_url_raw( $this->agile_data['InfoLink'] ),
				'showtimes'          => $this->get_all_showtimes(),
				'release_year'       => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Release Year' ) ),
				'rating'             => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Rating' ) ),
				'director'           => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Director' ) ),
				'starring'           => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Starring' ) ),
				'screenwriter'       => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Screenwriter' ) ),
				'producer'           => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Produced By' ) ),
				'music'              => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Music By' ) ),
				'agile_image_main'   => $this->agile_data['EventImage'],
				'agile_image_thumb'  => $this->agile_data['ThumbImage'],
				// phpcs:ignore Squiz.PHP.CommentedOutCode.Found
				// 'agile_media'        => $this->format_array_for_meta( $this->get_property_value( 'AdditionalMedia', 'Type', 'MediaEmbed', 'Image', true ) ),
				'youtube_id'         => $this->format_array_for_meta( $this->get_property_value( 'AdditionalMedia', 'Type', 'Value', 'YouTube' ) ),
				'language'           => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Original Language' ) ),
				'production_country' => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Production Country' ) ),
				'website'            => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Website' ) ),
				'facebook'           => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Facebook' ) ),
				'twitter'            => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Twitter' ) ),
				'start_date'         => $dates['start_date'],
				'end_date'           => $dates['end_date'],
			),
		);

		$taxonomies = array(
			'film_event_category' => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Series' ) ),
			'film_genre'          => $this->format_array_for_meta( $this->get_property_value( 'CustomProperties', 'Name', 'Value', 'Genre' ) ),
			'venue'               => $this->format_array_for_meta( $this->get_show_venues() ),
		);

		// Remove taxonomies with no found terms.
		foreach ( $taxonomies as $taxonomy => $terms ) {
			if ( ! $terms ) {
				unset( $taxonomies[$taxonomy] ); // phpcs:disable WordPress.Arrays.ArrayKeySpacingRestrictions.NoSpacesAroundArrayKeys
			}
		}

		if ( $taxonomies && ! empty( $taxonomies ) ) {
			$prepared_item['tax_input'] = $taxonomies;
		}

		$this->set_associated_post_id();
		$this->set_prepared_item( $prepared_item );
	}

	/**
	 * Sets the matching post ID for the associated Agile show item.
	 *
	 * @return void
	 */
	public function set_associated_post_id() {
		$posts = get_posts(
			array(
				'post_type'  => $this->post_type,
				'meta_query' => array(  // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => 'agile_show_id',
						'value'   => $this->agile_show_id,
						'compare' => '=',
					),
				),
			)
		);

		if ( $posts ) {
			$post_id = $posts[0]->ID;
		} else {
			$post_id = 0;
		}

		$this->post_id = $post_id;
	}

	/**
	 * Gets an item containing a value and returns the requested sibling value
	 *
	 * @param string  $key The data key that corresponds to the array to search.
	 * @param string  $item_label The label to search for within the $key array.
	 * @param string  $value_key The value key that stores the sought data.
	 * @param string  $find The value to search for.
	 * @param boolean $except Perform a negative search and return all values for Names except the `$find` parameter.
	 *                        (Default: false).
	 * @return array The found values
	 */
	public function get_property_value( $key, $item_label, $value_key, $find, $except = false ) {
		$arr = $this->agile_data[$key]; // phpcs:disable WordPress.Arrays.ArrayKeySpacingRestrictions.NoSpacesAroundArrayKeys

		$values = array();
		foreach ( array_keys( $arr ) as $key ) {
			if ( isset( $arr[$key][$item_label] ) ) {
				switch ( $except ) {
					case true:
						if ( $arr[$key][$item_label] !== $find ) {
							$values[] = $arr[$key][$value_key];
						}
						break;
					case false:
						if ( $arr[$key][$item_label] === $find ) {
							$values[] = $arr[$key][$value_key];
						}
						break;
				}
			}
		}
		// phpcs:enable WordPress.Arrays.ArrayKeySpacingRestrictions.NoSpacesAroundArrayKeys

		return $values;
	}

	/**
	 * Gets the venue(s) for invidual showings of an Agile show.
	 *
	 * @return array The `venue` taxonomy terms.
	 */
	public function get_show_venues() {
		$venues = array();
		foreach ( $this->agile_data['CurrentShowings'] as $showing ) {
			if ( ! in_array( $showing['Venue']['Name'], $venues, true ) ) {
				$venues[] = esc_textarea( $showing['Venue']['Name'], true );
			}
		}

		return $venues;
	}

	/**
	 * Assemble arrays for meta text fields where applicable.
	 *
	 * @param array $arr The array to serialize.
	 * @return array|string|null The data array, or a string if only one array element. Null if no value.
	 */
	public function format_array_for_meta( $arr ) {
		$result = null;
		$count  = count( $arr );

		switch ( $count ) {
			case 0:
				$result = null;
				break;
			case 1:
				$result = $arr[0];
				break;
			default:
				$result = $arr;
		}

		return $result;
	}

	/**
	 * Gets an item's start and end date range
	 *
	 * @return array The item's start and end dates.
	 */
	private function get_showings_date_range() {
		$dates = array(
			'start_date' => null,
			'end_date'   => null,
		);

		foreach ( $this->agile_data['CurrentShowings'] as $showing ) {
			$date = isset( $showing['StartDate'] ) ? new DateTime( $showing['StartDate'] ) : null;

			if ( ! $date ) {
				return;
			}

			$date->setTime( 0, 0 );

			if ( ! $dates['start_date'] || $date < $dates['start_date'] ) {
				$dates['start_date'] = $date->format( 'c' );
			}

			if ( ! $dates['end_date'] || $date > $dates['end_date'] ) {
				$dates['end_date'] = $date->format( 'c' );
			}
		}

		return $dates;
	}

	/**
	 * Gets a single Agile show's showtimes with associated purchase link and venue name.
	 *
	 * @return array Collection of showtimes: DateTime object and purchase link URL.
	 */
	public function get_all_showtimes() {
		$showtimes = array();
		foreach ( $this->agile_data['CurrentShowings'] as $showing ) {
			if ( isset( $showing['StartDate'] ) ) {
				$showtimes[] = array(
					'date'          => new DateTime( $showing['StartDate'] ),
					'purchase_link' => esc_url_raw( $showing['LegacyPurchaseLink'] ),
					'venue'         => $showing['Venue']['Name'],
				);
			}
		}

		return $showtimes;
	}
}
